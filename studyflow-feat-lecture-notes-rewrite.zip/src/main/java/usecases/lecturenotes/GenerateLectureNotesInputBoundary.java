package usecases.lecturenotes;

public interface GenerateLectureNotesInputBoundary {
    void execute(GenerateLectureNotesInputData inputData);
}