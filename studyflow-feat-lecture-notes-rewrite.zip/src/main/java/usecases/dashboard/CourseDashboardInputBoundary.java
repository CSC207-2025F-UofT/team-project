package usecases.dashboard;

public interface CourseDashboardInputBoundary {
    void getCourses();
    void createCourse();
}
